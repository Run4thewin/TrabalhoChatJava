/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;


/**
 *
 * @author Helton Gomes
 */
public class Musica extends Thread{
    
    @Override
    public void run(){
          URL oUrl, anotheroUrl;
   
              try {
                  oUrl = new URL("https://www.soundjay.com/button/button-2.wav");
                  Clip oClip = AudioSystem.getClip();
                  AudioInputStream oStream = AudioSystem.getAudioInputStream(oUrl);
                  oClip.open(oStream);
                  oClip.loop(0);
              }
              catch (MalformedURLException ex) {
                  Logger.getLogger(Musica.class.getName()).log(Level.SEVERE, null, ex);
              }
              catch (UnsupportedAudioFileException | LineUnavailableException | IOException ex) {
                  Logger.getLogger(Musica.class.getName()).log(Level.SEVERE, null, ex);
              }

            

    }
}
