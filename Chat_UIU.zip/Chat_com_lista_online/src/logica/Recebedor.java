/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;




/**
 *
 * @author Virginia
 */
public class Recebedor implements Runnable {

    private InputStream servidor;
    JTextArea txtBox;
    JLabel nPessoas;
    JTextArea pessoasOn;
    public Recebedor(InputStream servidor, JTextArea txtBox, JLabel nPessoas,JTextArea pessoasOn) {
        this.servidor = servidor;
        this.txtBox = txtBox;
        this.nPessoas = nPessoas;
        this.pessoasOn = pessoasOn;
    }

    @Override
    public void run() {
        // recebe msgs do servidor e imprime na tela
        Scanner s = new Scanner(this.servidor);
        while (s.hasNextLine()) {
            JSONObject json = new JSONObject();
            JSONParser parser = new JSONParser();
            String msg;
            String online;
            ArrayList<String> clientesBackup;
            String msgservidor = s.nextLine();
            
            try {
                json = (JSONObject) parser.parse(msgservidor);
            } catch (ParseException ex) {
                Logger.getLogger(Recebedor.class.getName()).log(Level.SEVERE, null, ex);
            }
            msg = (String) json.get("mensagem");
            online = (String) json.get("online");
            clientesBackup = (ArrayList<String>) json.get("lista");
            int o = Integer.parseInt(online.replace(" ",""));
            
            System.out.println(clientesBackup);
            
            txtBox.setText(txtBox.getText()+"\n"+ msg);
            nPessoas.setText(online + "pessoa(s) online");
            pessoasOn.setText("");
            for(int i =0;i<o;i++){
                pessoasOn.setText(clientesBackup.get(i) + " esta online \n");
            }
        }
    }
}
