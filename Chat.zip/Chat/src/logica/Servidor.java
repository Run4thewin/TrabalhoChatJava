/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.*;
/**
 * @author Virginia
 */
public class Servidor{
 
   private int porta;
   private List<PrintStream> clientes;
   private List<String> clientesBackup;
   private int numclientes = 0;
   
   public Servidor (int porta) {
     this.porta = porta;
     this.clientes = new ArrayList<>();
     this.clientesBackup = new ArrayList<>();
   }
     
   public static void main(String[] args) throws IOException {
     // inicia o servidor na porta 12345
     new Servidor(12345).executa();
   }
   
   public void executa() throws IOException {
     ServerSocket servidor = new ServerSocket(this.porta);
     System.out.println("Porta 12345 aberta!");
     
     while (true) {
       // aceita um cliente
       Socket cliente = servidor.accept();
       numclientes++;
       System.out.println("Nova conexão com o cliente " +   
         cliente.getInetAddress().getHostAddress()
       );
       System.out.println((numclientes)+" pessoa(s) online");
       
       // adiciona saida do cliente à lista
       PrintStream ps = new PrintStream(cliente.getOutputStream());
       this.clientes.add(ps);
       
       // cria tratador de cliente numa nova thread
       TrataCliente tc = new TrataCliente(cliente.getInputStream(), this);
       new Thread(tc).start();
     }
   
   
     
 
   }
 
   public void distribuiMensagem(String msg) {
     // envia msg para todo mundo
     for (PrintStream cliente : this.clientes){
         
         //{"Mensagem=" + msg + "Online=" + (num) + "Nomes=" + listanomes}
        
         JSONObject json = new JSONObject();
         
         if (msg.contains(" saiu do chat!300")){
             if(numclientes!= 0){
                 numclientes--;
             }
             String[] m = msg.split("!");
             msg = m[0];
             String[] nome = msg.split(" ");
             clientesBackup.remove(nome[0]);
         }
         
         if(msg.contains(" entrou no chat!")){
             String[] SplitMsg = msg.split(" ");
             String nome = SplitMsg[0];
             String mensagem = SplitMsg[1];
             String nome1 = new String();
            
             if (!clientesBackup.contains(nome))
                clientesBackup.add(nome);
             
             System.out.println(clientesBackup);
             
             
             
         }
         
         String on =  numclientes + " ";
         
         json.put("mensagem", msg);
         json.put("online",on);
         json.put("lista", clientesBackup);
         
         cliente.println(json);
     }
   }
   
   public List<String> getListCliente(){
       return this.clientesBackup;
   }
}